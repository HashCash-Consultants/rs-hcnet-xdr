#[test]
fn version() {
    std::println!("{:?}", stellar_xdr::VERSION);
}
